package karmaka.v1;

public class Joueur {

}
