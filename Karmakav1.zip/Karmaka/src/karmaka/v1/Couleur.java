package karmaka.v1;

public enum Couleur {
	ROUGE, BLEU, VERT, MULTI,
}
